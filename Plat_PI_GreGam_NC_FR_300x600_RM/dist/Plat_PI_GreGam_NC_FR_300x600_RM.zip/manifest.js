FT.manifest ({
"filename": "index.html",
"width": 300,
"height": 600,
"clickTagCount": 1,
"expand":{
	"width":600,
	"height":600,
	"indentAcross":300,
	"indentDown":0
	},
"hideBrowsers":["ie8", "ie9", "opera"],
"videos": [{"name": "video1", "ref": "51891/100147_Microsoft_XboxPlatform2015_FR_ONLINE_30s_02_NOSLATE"}]
});
